window.onResize = (width) => {
	console.log(width)
}

window.enterView = (msg) => {
	console.log('enter-view')
}
